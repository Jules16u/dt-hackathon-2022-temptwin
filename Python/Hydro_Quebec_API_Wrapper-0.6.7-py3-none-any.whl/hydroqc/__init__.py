"""Hydro Quebec API wrapper library."""
