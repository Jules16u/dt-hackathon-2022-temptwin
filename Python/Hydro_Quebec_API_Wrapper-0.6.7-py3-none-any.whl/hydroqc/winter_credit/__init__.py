"""Winter credit helper."""
